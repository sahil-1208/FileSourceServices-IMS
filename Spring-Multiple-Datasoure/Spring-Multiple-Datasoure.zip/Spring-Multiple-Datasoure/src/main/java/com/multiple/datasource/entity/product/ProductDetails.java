package com.multiple.datasource.entity.product;


import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import com.multiple.datasource.enums.ProductCategory;
import com.multiple.datasource.enums.ProductStatus;



@Entity
@Table(name = "product")
public class ProductDetails {

	@Id
	private Long productId;
	private String productName;
	private String description;
	private Long productPrize;
	private Long quantity;
	@Enumerated(EnumType.STRING)
	private ProductStatus productStatus;
	private Long supplierId;
	@Enumerated(EnumType.STRING)
	private ProductCategory productCategory;

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getProductPrize() {
		return productPrize;
	}

	public void setProductPrize(Long productPrize) {
		this.productPrize = productPrize;
	}

	public Long getQuantity() {
		return quantity;
	}

	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}

	public ProductStatus getProductStatus() {
		return productStatus;
	}

	public void setProductStatus(ProductStatus productStatus) {
		this.productStatus = productStatus;
	}

	public Long getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(Long supplierId) {
		this.supplierId = supplierId;
	}

	public ProductCategory getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(ProductCategory productCategory) {
		this.productCategory = productCategory;
	}
	


	
	

}
