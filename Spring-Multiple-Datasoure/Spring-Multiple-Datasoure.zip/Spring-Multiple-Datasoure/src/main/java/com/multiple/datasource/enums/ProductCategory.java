package com.multiple.datasource.enums;

public enum ProductCategory {
	ELECTRONICS, CLOTHING, FURNITURE, APPLIANCES, FOOTWEAR, MISCELLANEOUS;

}
